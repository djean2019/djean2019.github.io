$(document).ready(
    function(){
        $(bankForm).submit(
            function(evt){
                evt.preventDefault();
                let newAccount= $("#accountNum").val() +" | "+ $("#custName").val() + " | " + $("#acctType").val();
                $("#listAccount").append('<li>'+newAccount+'</li>');
            }
        )
    }
);